<html>
<head>
    <title>Tasks</title>
    <link href = https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css rel="stylesheet">
</head>
    
<body>
<div class = "container"> 
    @extends('tasks.layout')
   
@section('content')

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                {{ $task->name }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Detail:</strong>
                {{ $task->detail }}
            </div>
        </div>
    </div>

</div>
</body>

</html>