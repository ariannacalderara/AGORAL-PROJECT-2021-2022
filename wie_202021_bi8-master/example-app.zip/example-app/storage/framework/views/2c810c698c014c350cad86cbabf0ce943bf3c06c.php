<html>
<head>
    <title>Tasks</title>
    <link href = https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css rel="stylesheet">
</head>
<body>
    <div class="container">

    
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('tasks.update',$task->id)); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
       <div class="form-group">
         <strong>Name:</strong>
         <input type="text" name="name" value="<?php echo e($task->name); ?>" class="form-control" placeholder="Name">
         </div>
        </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
       <div class="form-group">
         <strong>Detail:</strong>
         <textarea class="form-control" style="height:150px" name="detail" placeholder="Detail" placeholder="Detail"><?php echo e($task->detail); ?></textarea>
         </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            
          </div>

     </div>
  </form>
  <?php $__env->stopSection(); ?>
    </div>
</body>
 </html>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>