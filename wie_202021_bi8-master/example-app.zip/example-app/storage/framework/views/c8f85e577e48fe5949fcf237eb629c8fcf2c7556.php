<html>
<head>
    <title>Tasks</title>
    <link href = https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css rel="stylesheet">
</head>
    
<body>
<div class = "container"> 
    
   
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($task->name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Detail:</strong>
                <?php echo e($task->detail); ?>

            </div>
        </div>
    </div>

</div>
</body>

</html>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/tasks/show.blade.php ENDPATH**/ ?>